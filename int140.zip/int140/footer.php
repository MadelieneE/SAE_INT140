        </div>

        <div id="footer">
            <p>Copyright <?php echo date(Y); ?> Kenshi.com. All rights Reserved User Agreement, Privacy.</p>
        </div>

    </div>

    </body>
</html>
