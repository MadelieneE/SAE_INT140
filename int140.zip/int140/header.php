<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8">
        <title>Kenshi.com</title>
        <link rel="stylesheet" href="style.css">
    </head>

    <body>

    <div id="container">
            <img class="logo" src="kenshi_logo.png" alt="My Profile Logo" />

            <div id="nav">
            <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="profile.php">My Profile</a></li>
            <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>

        <div id="content">
