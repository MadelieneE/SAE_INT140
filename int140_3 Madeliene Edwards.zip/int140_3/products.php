<div class="product">
    <h3>Jacket Blue</h3>
    <a href="add_to_cart.php?id=1">Add to Cart</a>
</div>
<div class="product">
    <h3>Jacket Grey</h3>
    <a href="add_to_cart.php?id=1">Add to Cart</a>
</div>
<div class="product">
    <h3>Jacket Black</h3>
    <a href="add_to_cart.php?id=1">Add to Cart</a>
</div>
<div class="product">
    <h3>Jacket White</h3>
    <a href="add_to_cart.php?id=1">Add to Cart</a>
</div>
