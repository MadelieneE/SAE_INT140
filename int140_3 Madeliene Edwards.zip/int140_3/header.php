<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
			*{margin: 0px;padding: 0px;}
			body{background: silver;}
			#header{width: 100%;height: 80px;background: #696969;box-shadow: 0px 2px 4px gray;}
			#logo{width:200px;height: 80px;float: left;padding-left:40px;}
			#navbar{width:1000px;height: 80px;margin: 0px auto;float: right;}
			#navbar>li{float: left;list-style: none;width: 190px;height: 80px;border-right:1px solid #534444;border-left: 1px solid #534444;}
			li>a{text-decoration: none;color: white;font-family: cursive;font-size: 20px;line-height: 80px;display: block;text-align: center;}
			li>a:hover,
			li>a:focus{background: red;color: #696969;}
			#res_btn{width: 50px;height: 50px;float: right;display: none;}
			@media screen and (max-width:1260px){
				#logo>img{width:150px;height: 60px;float: left;padding-left:20px;padding-top: 10px;}
				#navbar{width:800px;height: 80px;margin: 0px auto;float: right;}
				#navbar>li{float: left;list-style: none;width: 150px;height: 80px;border-right:1px solid #534444;border-left: 1px solid #534444;}
				li>a{text-decoration: none;color: white;font-family: cursive;font-size: 20px;line-height: 80px;display: block;text-align: center;}
			}
			@media screen and (max-width:1060px){
				#header{width: 100%;height: 80px;background: #696969;box-shadow: 0px 2px 4px gray;position:relative;top:80px;}
				#logo{width:100%;height: 90px;float: left;padding-left:20px;padding-top: 10px;position: absolute;top:-90px;background: white;}
				#navbar{width:100%;height: 60px;margin: 0px auto;}
				#navbar>li{width: 18%;}
				li>a{font-size: 16px;}
			}
			@media screen and (max-width:768px){
				#header{height: 50px;}
				#navbar{width:100%;height: 50px;margin: 0px auto;}
				#navbar>li{width: 19%;height: 50px;}
				li>a{font-size: 16px;line-height: 50px;}
			}
			@media screen and (max-width: 480px){
				#header{height: 0px;}
				#navbar{width:100%;height: 50px;margin: 0px auto;margin-top:-40px;
					display: none;}
				#navbar>li{float: none;list-style: none;width: 100%;height: 50px;background: #696969;border-bottom: 1px solid red;}
				li>a{font-size: 16px;line-height: 50px;}
				#res_btn{display: block;position: relative;top:-80px;cursor: pointer;}
			}
		</style>
	</head>
<body>

	<script type="text/javascript">
			var nav = false;
		function show_hide_nav(id){
			var navbar = document.getElementById(id);

			if(nav == false){
				navbar.style.display = "block";
				nav = true;
			}else{
				navbar.style.display = "none";
				nav = false;
			}
		}
	</script>
	<div id="header">
		<div id="logo"><img src="kenshi_logo.png" width="400px" height="80px"/></div>
		<div id="res_btn" onclick="show_hide_nav('navbar')" ><img style=width:100px;height:90px;  src="button_2.png"/></div>
		<ul id="navbar">
			<li><a href="index.php">Home</a></li>
			<li><a href="shoppingpage.php">Product</a></li>
			<li><a href="contact.php">Contact</a></li>
			<li><a href="checkout_form.php">Cart</a></li>
		</ul>
	</div>

</body>
</html>
