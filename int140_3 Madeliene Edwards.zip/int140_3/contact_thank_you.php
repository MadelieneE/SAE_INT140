<?php include 'header.php';?>
<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
  <p class="w3-center">Thank You For Contacting Us!</p>
</head>

</html>
