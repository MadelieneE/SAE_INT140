<?php include 'header.php';?>

<head>
    <meta charset="utf-8">
    <title>Thank You For Shopping Online with Kenshi.com</title>
    <link rel="stylesheet" href="style.css">
   <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
</head>

  <p class="w3-left">Thank You For Your Order!</p>
