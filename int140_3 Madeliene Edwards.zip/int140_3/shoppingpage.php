<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>

		input[type=submit] {
		  background-color: #FF0000;
		  color: white;
		  padding: 12px 20px;
		  border: none;
		  border-radius: 4px;
		  cursor: pointer;
		}
		/* When moving the mouse over the submit button, add a darker green color */
		input[type=submit]:hover {
		  background-color: #696969;
		}
		  </style>
		</head>
		<body>
  <?php include 'header.php';?>
  <table align='center'>
  	<tr>
			<div class="product">
  		<td>Jacket Blue</td>
  		<td><a href="add_to_cart.php?id=1">Add to Cart</a></td></div>
                  <td><img src="blue_jacket.jpg" style="width:400px;height:200px;"></td>
  	</tr>
  	<tr>
			<div class="product">
  		<td>Jacket Grey</td>
  		<td><a href="add_to_cart.php?id=2">Add to Cart</a></td></div>
                   <td><img src="grey_jacket.jpg" style="width:400px;height:200px;"></td>
  	</tr>
  	<tr>
			<div class="product">
  		<td>Jacket Black</td>
  		<td><a href="add_to_cart.php?id=3">Add to Cart</a></td></div>
                   <td><img src="black_jacket.jpg" style="width:400px;height:200px;"></td>
  	</tr>
		<tr>
			<div class="product">
			<td>Jacket White</td>
			<td><a href="add_to_cart.php?id=4">Add to Cart</a></td></div>
									 <td><img src="white_woman_jacket.jpg" style="width:400px;height:200px;"></td>
		</tr>
  </table>
</body>
</html>
