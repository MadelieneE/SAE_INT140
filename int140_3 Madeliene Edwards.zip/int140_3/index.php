<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include 'header.php';?>
</div>
  <div class="left"><a href="shoppingpage.php"><img style=width:450px;height:200px; src="male_jackets.jpg" alt="homepage image of male_jackets" />
    <p><a href="#male_jackets" </a></p>
  </div>
  <div class="left"><a href="shoppingpage.php"><img style=width:450px;height:200px; src="women_jackets.jpg" alt="homepage image of women_jackets" />
    <p><a href="#women_jackets" </a></p>
    </div>
    <div class="left"><a href="shoppingpage.php"><img style=width:450px;height:200px; src="him_hers2.jpg" alt="homepage image of women_jackets" />
      <p><a href="jackets" </a></p>
        </div>
    </div>
