<?php include 'header.php';?>

<img src="street_shoes.jpg" alt="homepage image of shoes" />

<h2>How <em>TO</em> create a statement?</h2>

<?php include 'footer.php';?>
