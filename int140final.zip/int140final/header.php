<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8">
        <title>Kenshi.com: Shop Online </title>
        <link rel="stylesheet" href="style.css">

    </head>

    <body>


    <div id="container">


            <div  class="sidenav">
              <h3 class="w3-wide"><b>KENSHI.COM></b></h3>
            <ul>
               <input type="text" placeholder="Search..">
            <li><a href="index.php">Home</a></li>
            <li><a href="profile.php">My Profile</a></li>
            <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>

        <div id="content">
