    <form action="./contact.php" method="get">
        <label for="firstname">First name:
        <input type="text" name="firstname" id="firstname"/></label>
    
        <label for="lastname">Last name:
        <input type="text" name="lastname" id="lastname"/></label>
        
        <label for="message">Your message:
        <textarea name="message" id="message"/></textarea></label>  
            
        <input type="submit" id="submit" value="SUBMIT"/>
    </form>