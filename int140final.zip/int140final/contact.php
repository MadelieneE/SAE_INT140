<?php include 'header.php';?>

<div id="leftcol">

    <h1>Contact Us</h1>

    <?php include 'form.php'; ?>

</div>

<div id="rightcol">
    <h3>More Details</h3>
    <strong>Address</strong>
    <p>123 Roma Street, Brisbane City QLD 4000</p>

    <strong>Phone</strong>
    <p>+61 073  079 99 </p>
</div>

<?php include 'footer.php';?>
