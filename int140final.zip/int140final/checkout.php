<?php
echo $_POST['body'];
?>