<!DOCTYPE html>
<html>
<body>

<h2>Radio Buttons</h2>

<form>
  <input type="radio" name="gender" value="male" checked> <img style=width:150px;height:150px;" src="https://pumaimages.azureedge.net/images/191592/01/sv01/fnd/PNA/h/600/w/600"><br>
  <input type="radio" name="gender" value="female"> <img style=width:150px;height:150px;" src="https://pumaimages.azureedge.net/images/191592/01/sv01/fnd/PNA/h/600/w/600"><br>
  <input type="radio" name="gender" value="other"> <img style=width:150px;height:150px;" src="https://pumaimages.azureedge.net/images/191592/01/sv01/fnd/PNA/h/600/w/600">  
</form> 

</body>
</html>
